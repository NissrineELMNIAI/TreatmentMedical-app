
package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class patient {

    @FXML
    private TableView<patient> patient;
    @FXML
    private TableColumn<patient, String> nomColumn;
    @FXML
    private TableColumn<patient, String> prenomColumn; 
     @FXML
    private TableColumn<patient, Double> dateColumn;
    @FXML
    private TableColumn<patient, String> sexeColumn; 
    
    @FXML
    private TextField nomField;
    @FXML
    private TextField prenomField;
    @FXML
    private TextField dateField;
    @FXML
    private TextField sexeField;
    
    @FXML
    private Button addButton;
    private DAOpatient DAOpatient;
    private ObservableList<patient> patientList;
    @FXML
    public void initilize(){
       DAOpatient = new DAOpatient();
        patientList = FXCollections.observableArrayList(DAOpatient.getAllProducts());
        
        nomColumn.setCellValueFactory(data->new javafx.beans.property.SimpleStringProperty(data.getValue().getNom()));
        prenomColumn.setCellValueFactory(data->new javafx.beans.property.SimpleObjectProperty<>(data.getValue().getPrenom()));
        dateColumn.setCellValueFactory(data->new javafx.beans.property.SimpleStringProperty(data.getValue().getDate()));
        sexeColumn.setCellValueFactory(data->new javafx.beans.property.SimpleObjectProperty<>(data.getValue().getSexe()));
        
        patientTable.setItems(patientList);
        
        addButton.setOnAction(event->addProduct());
      
                
    }
    private void addProduct(){
        String nom = nomField.getText();
        double prenom= Double.parseDouble(prenomField.getText());
        String dateNaiss = Double.parseDouble(dateField.getText());
        double sexe= sexeield.getText();
        
        patient newpatient= new patient(nom, prenom,dateNaiss, sexe);
        DAOpatient.addpatient(newpatient);
        patientList.add(newpatient);
        
        nameField.clear();
        priceField.clear();
            
    }
}

}
