
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class DAOpatient {

    private static final String URL = "jdbc:mysql://localhost3306/treatmentmedical_bd";
    private static final String USER = "root";
    private static final String PASSWORD = " ";
    private Connection connection;
    
    
    public DAOpatient(){
        try{
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    //methode pour visualiser tous les patients
    public List<patient> visualiser(){
        List<patient> products = new ArrayList<>();
        try{
            String query = "SELECT * FROM patient";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()){
                patient.add(new patient(rs.getInt("id"), rs.getString("nom"), rs.getString("prenom"),rs.getDouble("DateNaiss"),rs.getString("sexe")));
                
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return products;
    }
    
    public void ajouterpatient(patient patient){
        try{
            String query = "INSERT INTO patient(nom,prenom,DateNaiss, sexe)  VALUES ('lamyae','hamdaoui','20/01/2004' ,'femme')";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, patient.getNom());
            pstmt.setString(2, patient.getPrenom());
            pstmt.setDouble(3, patient.getDate());
            pstmt.setString(4, patient.getSexe());
            
            pstmt.executeUpdate();
        }catch(SQLException e){
        }
    }
    
    
}


