package model;

public class patient {
    private int id ;
    private String nom ;
    private String prenom ; 
    private double DateNaiss ;
    private String sexe ;
    
    //constructeur avec tous les attributs
    public patient (int id, String nom , String prenom , double DateNaiss, String sexe){
        this.id =id ; 
        this.prenom= prenom ; 
        this.nom =nom ; 
        this.DateNaiss= DateNaiss ; 
        this.sexe= sexe;
    }
      //constructeur avec sans id pour les neauveuax patients
    public patient ( String nom , String prenom , double DateNaiss, String sexe){
        this.prenom= prenom ; 
        this.nom =nom ; 
        this.DateNaiss= DateNaiss ; 
        this.sexe= sexe;
    }
    //getters & setters
    public int getID() {return id ; }
    public void setID(int id){this.id=id ; }
    
    public String getNom() {return nom; }
    public void setNom(String nom){this.nom=nom ; }
    
    public String getPrenom() {return prenom ; }
    public void setPrenom(String prenom){this.prenom=prenom ; }
    
    public double getDate() {return DateNaiss ; }
    public void setDate(double DateNaiss){this.DateNaiss=DateNaiss ; }
    
    public String getSexe() {return sexe; }
    public void setID(String sexe){this.sexe=sexe ; }
}
